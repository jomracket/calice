===================================================
        Nebula and Kawaks  Cheat Data Files        
                                                   
          Created by Monyons(Cheat Mania)          
                                                   
         http://cheatmania.vg-network.com/         
                                                   
                   Release No.11                   
===================================================
Release 11 (2001/10/01)
  NEOGEO cheats part.3

 [NEOGEO]
  *Added Fatal Fury 1.
  *Added Fatal Fury 2.
  *Added The King of Fighters '99.


Release 10 (2001/09/22)
  NEOGEO cheats part.2.

 [NEOGEO]
  *Added new codes for The King of Fighters '94.
  *Added new codes for The King of Fighters '95.
  *Added The King of Fighters '96.
  *Added The King of Fighters '97.
  *Added The King of Fighters '98.
  *Added PulStar.
  *Added Blazing Star.
  *Added Sengoku.
  *Added Sengoku2.
  *Added Twincle Star Sprites.
  *Added Ninja Combat.
  *Added Ninja Commando.
  *Added Nam 1975.
  *Added Goast Pilots.
  *Added Joy Joy Kid.


Release 9 (2001/09/14)
  *Modified 1941 weapon name.
  *Added NEO-GEO cheats.

 [NEOGEO]
  *Added Alpha Mission 2.
  *Added Art Of Fighting 2.
  *Added Fatal Fury Special.
  *Added Magician Lord.
  *Added Metal Slug 2 X.
  *Added Shock Troopers 2.
  *Added Sonic Wings 2.
  *Added Sonic Wings 3. (Some bugs)
  *Added The King of Fighters '94.
  *Added The King of Fighters '95.
  *Added Zed Blade.

Release 8 (2001/08/28)
  Added Japanese comment version. (for Kawaks Only)
  If you can read Japanese and if you like, get "jpn" archive.

 [CPS2]
  *Added Super Street Fighter 2.
  *Modified and Added Airen VS Predetor code.
   (Sorry, there were too many mistakes in this file.)
  *Modified Cyberbots.
  *Modified and Added Super Street Fighter 2 Turbo.
  *Modified and Added Street Fighter ZERO.
  *Modified and Added Street Fighter ZERO 3.
  *Modified and Added X-MEN vs Street Fighter.

 [CPS1]
  *Modified and Add Captain Commando.

Release 7 (2001/08/19)
  *CPS1 Cheats are not converted from CsD file for Callus95.
   These codes are re-searched for WinKawaks.
   Some problems and bugs of CsD file for Callus95 are already solved.
 [CPS1]
  *Added Magic Sword.
  *Added Willow.
  *Added Rockman The Power Battle.
  *Added Nemo.
  *Added Final Fight.
  *Added Forgotton World.
 [CPS2]
  *Added Quiz Nanairo Dreams.

Release 6 (2001/08/13)
 [CPS1]
  *Added 1941 The Counter Attack.
  *Added Area88.
  *Added Captain Commando.
  *Added Carrier Air Wing's.
  *Added Dai Makaimura.
  *Added King of Dragon's.
  *Added Knights of the Round.
  *Added Mercs.
  *Added Pang 3.
  *Added Varth.
 [CPS2]
  *Added Battle Circuit.
  *Added Eco Fighter.

Release 5 (2001/07/02)
  *Added Street Figher ALPHA
  *Added Powered Gear
  *Modified Cyberbots
  *Modified Vampire The Night Warriors
  *Modified Vampire Savior
  *Modified Street Fighter ZERO 2 Alpha (Character Code)
  *Modified Street Fighter ZERO 3 (Character Code)

Release 4 (2001/06/30)
  *Added Street Fighter ZERO 3 [sfa3/sfz3r1/sfz3jr1]
  *Added Street Fighter ZERO 2 Alpha [sfz2aj]

Release 3 (2001/04/21)
  *Added 19XX. [19xx]
  *Added Airen VS Predetor. [avsp]
  *Added Super Street Fighter 2 Turbo. [ssf2t]

Release 2 (2001/04/08)
  *Added Player 2 codes. [sfa2, xmcota, xmcotaj, msh, xmvsf]

Release 1 (2001/04/08)
  *Street Fighter Alpha 2 [sfa2]
  *X-MEN (English / Japanese) [xmcota / xmcotaj]
  *Marvel Super Heroes [msh]
  *X-MEN vs Street Fighter [xmvsf]
