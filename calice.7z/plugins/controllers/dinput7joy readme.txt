This is a controller plugin for Calice32.
Supports up to 10 button joystick.

YOU AT LEAST NEED CALICE 0.2.6a TO GET IT WORK.
WITH PREVIOUS VERSIONS IT WILL NOT WORK AND MAY HANG THE COMPUTER.


It allows fully configurable joystick/joypad for player 1
and keyboard controls for player 2 as follows:

UP, DOWN, LEFT, RIGHT to move player 2.
Button 1 -> Q
Button 2 -> W
Button 3- > E
Button 4 -> A
Button 5 -> S
Button 6 -> D

To use this plugin in Calice select Titorez plugin from setting->Controller->Choose 
then config buttons and directions as wanted

***KNOWN BUGS***
There seems to be an error displaying the correct value in the config window in some cases.

Will be fixed in the next releases.

If you notice error controlling player and pressing buttons try configuring again.

If this does not work delete titojoy.dat from calice32 directory and restart calice and
configure!
****************

Things to be added:

Configuration for 3 Punches and 3 Kicks.

Direct Input Version (hopefully this will add more speed and flexibility).


This plugin was made by Titorez (titorez@aruba.it).



***********Version History***************

05/05/2001  First public Version  0.7b


I hope you enjoy my work and have fun with Calice!!!


*********THANKS***********

Thanks David for Calice. Keep working on it!!!!

Thanks to all my beta testers:

Ivo
Son Goten
ayeye
Pepp Watang



****************WARNING WARNING*********************
USE THIS SOFTWARE AT YOUR OWN RISK.
IT IS PROVIDED AS IT IS.
TITOREZ (me) AND DAVID (author of Calice32) ARE NOT
RESPONSIBLE FOR ANY DAMAGE OR LOSS THAT MAY OCCUR 
TO YOUR COMPUTER!!!!
****************************************************



